var classfrontend_1_1pollables_1_1identifier__socket_1_1_identifier_socket =
[
    [ "__init__", "classfrontend_1_1pollables_1_1identifier__socket_1_1_identifier_socket.html#a6e4bff5d4dbe3c3deef464ad05797dba", null ],
    [ "__repr__", "classfrontend_1_1pollables_1_1identifier__socket_1_1_identifier_socket.html#afa028d4f4825c9991f833080970df4cc", null ],
    [ "fd", "classfrontend_1_1pollables_1_1identifier__socket_1_1_identifier_socket.html#ac971792d8143b1e075af07292a835148", null ],
    [ "get_events", "classfrontend_1_1pollables_1_1identifier__socket_1_1_identifier_socket.html#a4bb9c6a5e79beb07d43db486c3a8572e", null ],
    [ "is_terminating", "classfrontend_1_1pollables_1_1identifier__socket_1_1_identifier_socket.html#ad1aa5a9f7307340f1317e3c98add48df", null ],
    [ "on_close", "classfrontend_1_1pollables_1_1identifier__socket_1_1_identifier_socket.html#afb03533c1e6b98ceaa0ae40f5b200084", null ],
    [ "on_idle", "classfrontend_1_1pollables_1_1identifier__socket_1_1_identifier_socket.html#a8a80b19981c29efbeb49c7c4370aa82c", null ],
    [ "on_read", "classfrontend_1_1pollables_1_1identifier__socket_1_1_identifier_socket.html#a329c5d4c2efc6f354944a9cd08a0fc70", null ],
    [ "update_disconnected", "classfrontend_1_1pollables_1_1identifier__socket_1_1_identifier_socket.html#ae22c4ce964f467c8cfee8511d3b0f486", null ],
    [ "update_disk", "classfrontend_1_1pollables_1_1identifier__socket_1_1_identifier_socket.html#a1863040974196d1535f79b78eaf371ed", null ]
];