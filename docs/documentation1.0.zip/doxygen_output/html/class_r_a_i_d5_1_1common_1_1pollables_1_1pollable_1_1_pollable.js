var class_r_a_i_d5_1_1common_1_1pollables_1_1pollable_1_1_pollable =
[
    [ "get_events", "class_r_a_i_d5_1_1common_1_1pollables_1_1pollable_1_1_pollable.html#a14860df1cb88e4cfa7e5ce0a066e55c6", null ],
    [ "is_terminating", "class_r_a_i_d5_1_1common_1_1pollables_1_1pollable_1_1_pollable.html#aad042c9fbe6554403349310be32824c7", null ],
    [ "on_error", "class_r_a_i_d5_1_1common_1_1pollables_1_1pollable_1_1_pollable.html#ad31d3a7892af98c5e5e51e1bbb69b7b0", null ],
    [ "on_idle", "class_r_a_i_d5_1_1common_1_1pollables_1_1pollable_1_1_pollable.html#af261ececf5f5e21d95611e7a1a9b01e3", null ],
    [ "on_read", "class_r_a_i_d5_1_1common_1_1pollables_1_1pollable_1_1_pollable.html#a9a989d7ddd2aa7ffcaa349c0e9f47880", null ],
    [ "on_write", "class_r_a_i_d5_1_1common_1_1pollables_1_1pollable_1_1_pollable.html#ac98ba12dcc8968d74b0b11bc083315de", null ]
];