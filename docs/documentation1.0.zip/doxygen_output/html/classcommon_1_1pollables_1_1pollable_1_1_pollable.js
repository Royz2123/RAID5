var classcommon_1_1pollables_1_1pollable_1_1_pollable =
[
    [ "get_events", "classcommon_1_1pollables_1_1pollable_1_1_pollable.html#a4d44af8da2502503040b740a62f85615", null ],
    [ "is_terminating", "classcommon_1_1pollables_1_1pollable_1_1_pollable.html#a06d5eb09a6084ee59e9afbb4910d95aa", null ],
    [ "on_error", "classcommon_1_1pollables_1_1pollable_1_1_pollable.html#a471dcca34dca1325e37cff9b9170fa96", null ],
    [ "on_idle", "classcommon_1_1pollables_1_1pollable_1_1_pollable.html#a8d38640f18c1ad366d5d8d4ba969bb87", null ],
    [ "on_read", "classcommon_1_1pollables_1_1pollable_1_1_pollable.html#a93360cda82180c5a34f217d66c88c6e1", null ],
    [ "on_write", "classcommon_1_1pollables_1_1pollable_1_1_pollable.html#a578102695355db4e21dce2e2f8dc2de0", null ]
];