var classblock__device_1_1services_1_1set__disk__info__service_1_1_set_disk_info_service =
[
    [ "__init__", "classblock__device_1_1services_1_1set__disk__info__service_1_1_set_disk_info_service.html#aa97f477cb421dd1fb4fb2c8269a3da39", null ],
    [ "file_handle", "classblock__device_1_1services_1_1set__disk__info__service_1_1_set_disk_info_service.html#ac70913873c714d66f9f2151e65029d93", null ]
];