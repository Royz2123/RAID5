var classcommon_1_1utilities_1_1util_1_1_disk_refused =
[
    [ "__init__", "classcommon_1_1utilities_1_1util_1_1_disk_refused.html#ae4cfb3756717b504f6141e58d821ec10", null ],
    [ "disk_UUID", "classcommon_1_1utilities_1_1util_1_1_disk_refused.html#a355211b41b76d0ae454c577b5a30b5d3", null ]
];