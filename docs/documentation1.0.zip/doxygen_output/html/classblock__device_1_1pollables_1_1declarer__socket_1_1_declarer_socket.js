var classblock__device_1_1pollables_1_1declarer__socket_1_1_declarer_socket =
[
    [ "__init__", "classblock__device_1_1pollables_1_1declarer__socket_1_1_declarer_socket.html#af58ceec4ef553d912d6a1b763047f499", null ],
    [ "__repr__", "classblock__device_1_1pollables_1_1declarer__socket_1_1_declarer_socket.html#a7b655f936ef95c7d0a760ff2c0209a0a", null ],
    [ "create_content", "classblock__device_1_1pollables_1_1declarer__socket_1_1_declarer_socket.html#a089f4d66da2be946d3c1b04b3a769ed5", null ],
    [ "fd", "classblock__device_1_1pollables_1_1declarer__socket_1_1_declarer_socket.html#a164d68bd5b79ea1fa14965dc537ecda8", null ],
    [ "get_events", "classblock__device_1_1pollables_1_1declarer__socket_1_1_declarer_socket.html#a31a810a80bea2594f2164a93658c0651", null ],
    [ "is_terminating", "classblock__device_1_1pollables_1_1declarer__socket_1_1_declarer_socket.html#a7cca193206910ab7f4e893dcf44f4e3d", null ],
    [ "on_close", "classblock__device_1_1pollables_1_1declarer__socket_1_1_declarer_socket.html#adb35b23f252b02a80b59b3f13c106cf4", null ],
    [ "on_idle", "classblock__device_1_1pollables_1_1declarer__socket_1_1_declarer_socket.html#a8c842f2318907e385e2c90811510bc27", null ],
    [ "socket", "classblock__device_1_1pollables_1_1declarer__socket_1_1_declarer_socket.html#ae11589efaf7655909b13ed2022ba53da", null ]
];