var searchData=
[
  ['xor_5fblocks',['xor_blocks',['../namespace_r_a_i_d5_1_1frontend_1_1utilities_1_1disk__util.html#a2f42f895de16150b5df7dd3b05bf55ed',1,'RAID5::frontend::utilities::disk_util']]]
];
