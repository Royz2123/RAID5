var searchData=
[
  ['baseservice',['BaseService',['../classcommon_1_1services_1_1base__service_1_1_base_service.html',1,'common::services::base_service']]],
  ['bdsclientsocket',['BDSClientSocket',['../classfrontend_1_1pollables_1_1bds__client__socket_1_1_b_d_s_client_socket.html',1,'frontend::pollables::bds_client_socket']]]
];
