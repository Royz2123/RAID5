var searchData=
[
  ['wanted_5fheaders',['wanted_headers',['../classcommon_1_1services_1_1base__service_1_1_base_service.html#ae70562c0a3db938416dc5d9e7091e8e0',1,'common::services::base_service::BaseService']]]
];
