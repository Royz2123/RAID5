var annotated_dup =
[
    [ "block_device", null, [
      [ "pollables", null, [
        [ "declarer_socket", null, [
          [ "DeclarerSocket", "classblock__device_1_1pollables_1_1declarer__socket_1_1_declarer_socket.html", "classblock__device_1_1pollables_1_1declarer__socket_1_1_declarer_socket" ]
        ] ]
      ] ],
      [ "services", null, [
        [ "get_block_service", null, [
          [ "GetBlockService", "classblock__device_1_1services_1_1get__block__service_1_1_get_block_service.html", "classblock__device_1_1services_1_1get__block__service_1_1_get_block_service" ]
        ] ],
        [ "get_disk_info_service", null, [
          [ "GetDiskInfoService", "classblock__device_1_1services_1_1get__disk__info__service_1_1_get_disk_info_service.html", "classblock__device_1_1services_1_1get__disk__info__service_1_1_get_disk_info_service" ]
        ] ],
        [ "login_service", null, [
          [ "LoginService", "classblock__device_1_1services_1_1login__service_1_1_login_service.html", "classblock__device_1_1services_1_1login__service_1_1_login_service" ]
        ] ],
        [ "set_block_service", null, [
          [ "SetBlockService", "classblock__device_1_1services_1_1set__block__service_1_1_set_block_service.html", "classblock__device_1_1services_1_1set__block__service_1_1_set_block_service" ]
        ] ],
        [ "set_disk_info_service", null, [
          [ "SetDiskInfoService", "classblock__device_1_1services_1_1set__disk__info__service_1_1_set_disk_info_service.html", "classblock__device_1_1services_1_1set__disk__info__service_1_1_set_disk_info_service" ]
        ] ],
        [ "update_level_service", null, [
          [ "UpdateLevelService", "classblock__device_1_1services_1_1update__level__service_1_1_update_level_service.html", "classblock__device_1_1services_1_1update__level__service_1_1_update_level_service" ]
        ] ]
      ] ]
    ] ],
    [ "common", null, [
      [ "pollables", null, [
        [ "callable", null, [
          [ "Callable", "classcommon_1_1pollables_1_1callable_1_1_callable.html", "classcommon_1_1pollables_1_1callable_1_1_callable" ]
        ] ],
        [ "listener_socket", null, [
          [ "ListenerSocket", "classcommon_1_1pollables_1_1listener__socket_1_1_listener_socket.html", "classcommon_1_1pollables_1_1listener__socket_1_1_listener_socket" ]
        ] ],
        [ "pollable", null, [
          [ "Pollable", "classcommon_1_1pollables_1_1pollable_1_1_pollable.html", "classcommon_1_1pollables_1_1pollable_1_1_pollable" ]
        ] ],
        [ "service_socket", null, [
          [ "ServiceSocket", "classcommon_1_1pollables_1_1service__socket_1_1_service_socket.html", "classcommon_1_1pollables_1_1service__socket_1_1_service_socket" ]
        ] ]
      ] ],
      [ "services", null, [
        [ "base_service", null, [
          [ "BaseService", "classcommon_1_1services_1_1base__service_1_1_base_service.html", "classcommon_1_1services_1_1base__service_1_1_base_service" ]
        ] ],
        [ "form_service", null, [
          [ "FileFormService", "classcommon_1_1services_1_1form__service_1_1_file_form_service.html", "classcommon_1_1services_1_1form__service_1_1_file_form_service" ]
        ] ],
        [ "get_file_service", null, [
          [ "GetFileService", "classcommon_1_1services_1_1get__file__service_1_1_get_file_service.html", "classcommon_1_1services_1_1get__file__service_1_1_get_file_service" ]
        ] ]
      ] ],
      [ "utilities", null, [
        [ "async_server", null, [
          [ "AsyncServer", "classcommon_1_1utilities_1_1async__server_1_1_async_server.html", "classcommon_1_1utilities_1_1async__server_1_1_async_server" ]
        ] ],
        [ "poller", null, [
          [ "Poller", "classcommon_1_1utilities_1_1poller_1_1_poller.html", "classcommon_1_1utilities_1_1poller_1_1_poller" ],
          [ "Select", "classcommon_1_1utilities_1_1poller_1_1_select.html", "classcommon_1_1utilities_1_1poller_1_1_select" ]
        ] ],
        [ "state_util", null, [
          [ "state", null, [
            [ "State", "classcommon_1_1utilities_1_1state__util_1_1state_1_1_state.html", "classcommon_1_1utilities_1_1state__util_1_1state_1_1_state" ]
          ] ],
          [ "state_machine", null, [
            [ "StateMachine", "classcommon_1_1utilities_1_1state__util_1_1state__machine_1_1_state_machine.html", "classcommon_1_1utilities_1_1state__util_1_1state__machine_1_1_state_machine" ]
          ] ]
        ] ],
        [ "util", null, [
          [ "Disconnect", "classcommon_1_1utilities_1_1util_1_1_disconnect.html", "classcommon_1_1utilities_1_1util_1_1_disconnect" ],
          [ "DiskRefused", "classcommon_1_1utilities_1_1util_1_1_disk_refused.html", "classcommon_1_1utilities_1_1util_1_1_disk_refused" ],
          [ "InvalidArguments", "classcommon_1_1utilities_1_1util_1_1_invalid_arguments.html", "classcommon_1_1utilities_1_1util_1_1_invalid_arguments" ]
        ] ]
      ] ]
    ] ],
    [ "frontend", null, [
      [ "pollables", null, [
        [ "bds_client_socket", null, [
          [ "BDSClientSocket", "classfrontend_1_1pollables_1_1bds__client__socket_1_1_b_d_s_client_socket.html", "classfrontend_1_1pollables_1_1bds__client__socket_1_1_b_d_s_client_socket" ]
        ] ],
        [ "identifier_socket", null, [
          [ "IdentifierSocket", "classfrontend_1_1pollables_1_1identifier__socket_1_1_identifier_socket.html", "classfrontend_1_1pollables_1_1identifier__socket_1_1_identifier_socket" ]
        ] ]
      ] ],
      [ "services", null, [
        [ "client_services", null, [
          [ "ClientService", "classfrontend_1_1services_1_1client__services_1_1_client_service.html", "classfrontend_1_1services_1_1client__services_1_1_client_service" ]
        ] ],
        [ "connect_service", null, [
          [ "ConnectService", "classfrontend_1_1services_1_1connect__service_1_1_connect_service.html", "classfrontend_1_1services_1_1connect__service_1_1_connect_service" ]
        ] ],
        [ "disconnect_service", null, [
          [ "DisconnectService", "classfrontend_1_1services_1_1disconnect__service_1_1_disconnect_service.html", "classfrontend_1_1services_1_1disconnect__service_1_1_disconnect_service" ]
        ] ],
        [ "display_disks_service", null, [
          [ "DisplayDisksService", "classfrontend_1_1services_1_1display__disks__service_1_1_display_disks_service.html", "classfrontend_1_1services_1_1display__disks__service_1_1_display_disks_service" ]
        ] ],
        [ "init_service", null, [
          [ "InitService", "classfrontend_1_1services_1_1init__service_1_1_init_service.html", "classfrontend_1_1services_1_1init__service_1_1_init_service" ]
        ] ],
        [ "read_disk_service", null, [
          [ "ReadFromDiskService", "classfrontend_1_1services_1_1read__disk__service_1_1_read_from_disk_service.html", "classfrontend_1_1services_1_1read__disk__service_1_1_read_from_disk_service" ]
        ] ],
        [ "write_disk_service", null, [
          [ "WriteToDiskService", "classfrontend_1_1services_1_1write__disk__service_1_1_write_to_disk_service.html", "classfrontend_1_1services_1_1write__disk__service_1_1_write_to_disk_service" ]
        ] ]
      ] ],
      [ "utilities", null, [
        [ "cache", null, [
          [ "Cache", "classfrontend_1_1utilities_1_1cache_1_1_cache.html", "classfrontend_1_1utilities_1_1cache_1_1_cache" ]
        ] ],
        [ "disk_manager", null, [
          [ "DiskManager", "classfrontend_1_1utilities_1_1disk__manager_1_1_disk_manager.html", "classfrontend_1_1utilities_1_1disk__manager_1_1_disk_manager" ]
        ] ]
      ] ]
    ] ],
    [ "RAID5", null, [
      [ "block_device", null, [
        [ "pollables", null, null ],
        [ "services", null, null ]
      ] ],
      [ "common", null, [
        [ "pollables", null, null ],
        [ "services", null, null ],
        [ "utilities", null, null ]
      ] ],
      [ "frontend", null, [
        [ "pollables", null, null ],
        [ "services", null, null ],
        [ "utilities", null, null ]
      ] ]
    ] ]
];